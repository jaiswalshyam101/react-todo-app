import { useContext, useEffect, useState } from "react"
import TodoContext from "../context/TodoContext"

const Form = () => {

     const {addTodo, edit, updateTodo} = useContext(TodoContext)


    const [input, setInput] = useState("")

    const handleSubmit = (e) => {
        e.preventDefault()

        !edit.isEdit ?
            addTodo({
                id: crypto.randomUUID(),
                text: input
            }) : updateTodo({
                id: edit.todo.id,
                text: input
            })
        setInput("")

    }

    useEffect(() => {
        setInput(edit.todo.text)
    }, [edit])

    return (
        <form onSubmit={(e) => handleSubmit(e)} className="p-4 border border-gray-400 shadow-sm">
            <input value={input} onChange={(e) => setInput(e.target.value)} type="text" placeholder="Enter Todo" className="p-2 border border-gray-500 w-full" />
            <button className="w-full bg-green-500 hover:bg-green-600 cusor-pointer p-2 my-4">Save</button>
        </form>
    )
}
export default Form